from django.contrib import admin
from .models import theTask, Assessment
# Register your models here.

admin.site.register(theTask)
admin.site.register(Assessment)
